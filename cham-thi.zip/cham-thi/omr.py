import cv2, numpy as np, imutils

def detect_part1(image):
    # ABCD – 40 câu
    return {}  # placeholder (bạn đã có logic bubble, gắn vào đây)

def detect_part2(image):
    # Đúng/Sai – 8 câu × a b c d
    return {}

def detect_part3(image):
    # Trả lời ngắn – 6 câu (0–9)
    return {}

def detect_exam_code(image):
    return "101"